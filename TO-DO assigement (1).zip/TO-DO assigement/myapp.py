from flask import Flask, flash, redirect, render_template, request, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///lists.sqlite3'
app.config['SECRET_KEY'] = 'AS62nsfjadsaj_@dfjfsfhbf182sfjdfASFAKSF'


db = SQLAlchemy(app)

class List(db.Model):
    id = db.Column('id', db.Integer, primary_key=True)
    
    name = db.Column(db.String(100))
    email = db.Column(db.String(100))
    phone = db.Column(db.Integer)
    priority = db.Column(db.String(100))

    def __init__(self, name,email, phone,priority):
   
        self.name = name
        self.email = email
        self.phone = phone
        self.priority = priority
        


@app.route('/')
def index():
    lists = List.query.all()
    print(lists)
    return render_template('list.html', lists=lists)


@app.route('/add', methods=['GET', 'POST'])
def add():
    msg = None
    if request.method == 'POST':
        try:
            list = List(request.form['name'], request.form['email'], request.form['phone'],request.form['priority'])
            db.session.add(list)
            db.session.commit()

            flash('task addition successful')
            return redirect(url_for('index'))
        except:
            msg = 'Error adding task'

    return render_template('add.html', msg=msg)


@app.route('/delete/<id>')
def delete(id):
    try:
        List.query.filter_by(id=id).delete()
        db.session.commit()
        flash('Deletion successful')
    except:
        flash('Unable to delete!')

    return redirect(url_for('index'))


@app.route('/edit/<id>', methods=['GET', 'POST'])
def edit(id):
    list = List.query.filter_by(id=id).first()

    if request.method == 'POST':
        try:
           
            list.name = request.form['name'] 
            list.email = request.form['email']
            list.phone = request.form['phone']
            list.priority = request.form['priority']
            
            
            db.session.commit()

            flash('Update successful')
        except:
            flash('Error updating task!')

        return redirect(url_for('index'))
    else:
        return render_template('edit.html', list=list)


if __name__ == '__main__':
    db.create_all()

    app.run(debug=True)
